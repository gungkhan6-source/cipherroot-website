# Immersive Experience Engine

Standalone, framework-free hero engine built on Three.js/WebGL. Thousands of GPU
particles assemble into procedural forms, react to the pointer and morph as the
user scrolls. Experiences are presets:

- **`mindFormationPreset`** (default): a loose field becomes a neural network,
  a digital brain and a humanoid head, then dissolves back into particles.
- **`gamesPreset`** (`immersive-experience-engine/games`): an arcade cabinet
  morphs into a controller, a handheld console, an isometric pixel world and
  back into the cabinet.
- **`blogPreset`** (`immersive-experience-engine/blog`), "Ink & Signal": an
  article page morphs into a discovery lens over a card index, a media orbit,
  a globe of idea words and back into the page.
- **`appsPreset`** (`immersive-experience-engine/apps`), "App Nexus": a digital
  globe becomes a global mesh, a human interface with a flock of birds and a
  honeycomb of app modules around a crystal core, then the globe again.

Status: **apps sequence and the per-particle motion channel** (v0.5.0).

## Quick Start

```bash
npm install
npm run dev
```

Open http://localhost:5199 for the mind formation demo,
http://localhost:5199/games.html for the games sequence,
http://localhost:5199/blog.html for the blog sequence and
http://localhost:5199/apps.html for the apps sequence. Query parameters:

- `?debug` — tier, particle count, FPS and timeline state
- `?tier=high|medium|low|fallback` — force a quality tier
- `?form=arcade|controller|handheld|pixel-world` (games page),
  `?form=page|lens|media|globe` (blog page) or
  `?form=globe|mesh|head|nexus` (apps page) — one form only

## Usage

```ts
import { createImmersiveEngine } from "immersive-experience-engine";

const engine = createImmersiveEngine({
  container: document.querySelector("#hero-stage")!, // positioned element
  scrollTarget: document.querySelector("#hero")!, // tall wrapper with a sticky viewport
});

// later
engine.dispose();
```

`three` is a peer dependency. The engine returns immediately and builds the
scene when the browser is idle, so it never blocks page content.

### Entries

| Import | Contents |
| ------ | -------- |
| `immersive-experience-engine` | `createImmersiveEngine`, `mindFormationPreset`, mind formation forms, basic forms, timeline, shared types and constants |
| `immersive-experience-engine/games` | `gamesPreset`, games forms, `neonGamesFallback` |
| `immersive-experience-engine/blog` | `blogPreset`, blog forms, `editorialFallback` |
| `immersive-experience-engine/apps` | `appsPreset`, apps forms, `appNexusFallback` |

The core entry does not contain any games, blog or apps code, so a page with
the mind formation never downloads them. Shared helpers live in
`dist/chunks/`.

> 0.4.0 moved `gamesPreset` and the games forms from the core entry to
> `immersive-experience-engine/games`.

### Presets

An `ExperiencePreset` bundles everything an experience needs: the stage forms,
the timeline, camera and per-stage views, shader effects, morph delays, lights,
palette and the static fallback. Pass one with `preset`; without it the engine
uses `mindFormationPreset`.

```ts
import { createImmersiveEngine } from "immersive-experience-engine";
import { gamesPreset } from "immersive-experience-engine/games";

const engine = createImmersiveEngine({
  container: document.querySelector("#hero-stage")!,
  scrollTarget: document.querySelector("#hero")!,
  avoid: [...document.querySelectorAll(".hero__copy > *")], // headline, copy, CTA
  preset: gamesPreset,
});
```

- `palette` still overrides the preset colors, and `forms` still replaces the
  preset's stage chain.
- Presets are plain objects, so a variant is a spread:
  `{ ...gamesPreset, stageViews: [...] }`.
- With a dynamic import, load the core and the experience together:
  `Promise.all([import("immersive-experience-engine"), import("immersive-experience-engine/blog")])`.

### Games sequence

```text
intro   field → Arcade
scroll  Arcade → Controller → Handheld → Pixel World → Arcade
up      the same chain in reverse; no dissolve at the end
```

- True particle morphs: every step moves the same particles from one form to
  the next (matched to nearby targets), with a wide morph window so the whole
  shape deforms instead of a front sweeping across it.
- Each stage has its own view: the cabinet 3/4 from the front, the controller
  slightly from above, the handheld from the front, the pixel world
  isometric.
- The screen keeps its identity: the cabinet screen, the controller buttons,
  the handheld screen and the pixel world coins and hero share a labelled
  group, so the lit "screen" travels as one cluster through every morph.
- Neon effects stay subtle: a light glow near the pointer, a slow neon pulse
  and a very small depth bulge. The pointer barely displaces particles, so
  screens and pixel figures keep their edges.
- The games fallback is a procedural SVG controller over a neon grid and
  gradient (no image assets).

### Blog sequence: Ink & Signal

```text
intro   ink field → Page
scroll  Page → Discovery Lens → Media Orbit → Idea Globe → Page
up      the same chain in reverse; no dissolve at the end
```

```ts
import { createImmersiveEngine } from "immersive-experience-engine";
import { blogPreset } from "immersive-experience-engine/blog";

createImmersiveEngine({ container, scrollTarget, avoid, preset: blogPreset });
```

- **Page**: a gently bent article page with a kicker, a coral headline, a
  picture frame, paragraphs of abstract word runs, an amber cursor, two fanned
  sheets and signal arcs.
- **Discovery Lens**: a 3 × 3 card index on a desk and a magnifying ring facing
  the viewer, with magnified lines and a mint trend line.
- **Media Orbit**: a video card with a play glyph and progress bar, and five
  media tiles (waveform, picture, text, chart, pin) on a dashed orbit.
- **Idea Globe**: latitude bands of word capsules, highlighted words, large
  quotation marks and rising idea sparks.
- No real text anywhere: words are abstract runs and capsules.
- Text marks (`TEXT_GROUP`) and the focal accent (`ACCENT_GROUP`) are matched
  group to group along the chain, so paragraph lines lie down as card lines,
  become tile contents and word bands, and flatten back into paragraphs; the
  headline turns into the lens trend, the play glyph and the quotation marks.
- Forms adapt their detail to the particle count (fewer, longer lines on the
  low tier) so lines stay lines.
- Palette "warm editorial": cream, indigo, coral, amber and mint. Effects are
  subtle: `pointerMagnify` enlarges points near the pointer without moving
  them, and `readingSweep` lets a faint band travel along the rows.
- The blog fallback is a procedural SVG article page with a lens and signal
  arcs (no image assets).

### Apps sequence: App Nexus

```text
intro   field → Digital Globe
scroll  Digital Globe → Global Mesh → Human Interface → App Nexus → Digital Globe
up      the same chain in reverse; no dissolve at the end
```

```ts
import { createImmersiveEngine } from "immersive-experience-engine";
import { appsPreset } from "immersive-experience-engine/apps";

createImmersiveEngine({ container, scrollTarget, avoid, preset: appsPreset });
```

- **Digital Globe**: meridians and parallels, land clusters snapped to a
  geodesic lattice, an inclined orbit ring, hub arcs with travelling packets
  and a lit core.
- **Global Mesh**: a geodesic lattice of beams and nodes seen from closer in,
  with vault arcs, packets, a horizon ellipse and drop lines — geometric, so it
  never reads like the mind formation's neural network.
- **Human Interface**: an abstract profile head (no facial detail) drawn as an
  outline shell with contour nodes, and a flock of birds inside and around it;
  birds leaving the head climb a widening arc.
- **App Nexus**: a curved hexagonal wall of app modules with abstract glyphs, a
  base ring, install arcs, and links carrying data points to an octahedron
  crystal core.
- Links (`LINK_GROUP`) and nodes (`NODE_GROUP`) are matched group to group
  along the chain, so hub arcs become mesh beams, then the flock, then the
  module links, and land back on the globe.
- The birds keep flapping: a per-particle motion channel (`aMotion`) gives each
  wing point a phase and a signed lever, and the `wingFlap` effect moves it on
  the GPU. A gate closes the flap during the morphs on either side, so the wings
  never distort the shapes in transit. 18 / 11 / 6 birds on high / medium / low.
- Palette "titanium aurora": titanium, teal, rose, lime and ice blue. The
  pointer gently attracts particles (`pointerPush` is negative) and
  `pointerMagnify` enlarges points near it without moving them.
- The apps fallback is a procedural SVG honeycomb with a crystal core, links
  and an orbit ring (no image assets).

### Reduced motion and fallback

With `prefers-reduced-motion: reduce`, no WebGL or a very slow device, the
engine creates no canvas and no WebGL context. It renders the preset's static,
decorative (`aria-hidden`) fallback instead: a still constellation for the mind
formation, the neon controller for games, the editorial page for the blog, the
app nexus for apps. A
preset can supply any `FallbackIllustration` (a name and a `draw(palette)`
function returning an SVG). Page copy and CTAs stay untouched in the DOM. To skip downloading the engine entirely under reduced motion, check
`matchMedia("(prefers-reduced-motion: reduce)")` before a dynamic `import()`
and show your own static background.

## Packaging

The package ships the ES module builds (core, `games`, `blog`, `apps` and
shared chunks)
and type declarations only (source maps are excluded from the tarball):

```bash
npm run build
npm pack --pack-destination <consumer>/vendor
```

A consumer installs the versioned tarball, which npm copies into
`node_modules` (no symlink, so bundlers with a project-root boundary such as
Turbopack and hosted builds resolve it like any other dependency):

```json
"dependencies": {
  "immersive-experience-engine": "file:vendor/immersive-experience-engine-0.5.0.tgz",
  "three": "^0.186.0"
}
```

## React / Next.js Integration

The engine is framework-free and touches `window`, so load it on the client
only, after mount, and dispose it on unmount:

```tsx
"use client";

import { useEffect, useRef } from "react";

export function ImmersiveStage() {
  const stage = useRef<HTMLDivElement>(null);

  useEffect(() => {
    let cancelled = false;
    let engine: { dispose(): void } | null = null;

    import("immersive-experience-engine").then(({ createImmersiveEngine }) => {
      const container = stage.current;
      if (cancelled || !container) return;
      const hero = container.closest<HTMLElement>("[data-immersive-hero]") ?? container;
      engine = createImmersiveEngine({
        container,
        scrollTarget: hero, // tall wrapper with a sticky viewport inside
        avoid: [...hero.querySelectorAll("[data-immersive-avoid]")], // headline, copy, CTAs
      });
    });

    return () => {
      cancelled = true; // also safe under React Strict Mode double mounting
      engine?.dispose();
    };
  }, []);

  return <div ref={stage} aria-hidden="true" style={{ position: "absolute", inset: 0 }} />;
}
```

- Keep the headline and CTA in server-rendered HTML; the canvas is decorative
  (`aria-hidden`) and the engine never blocks first paint.
- The dynamic `import()` keeps the engine and three.js in a separate client
  chunk, downloaded only when the component actually mounts (e.g. behind a
  feature flag).
- Pass `preset` (for example `gamesPreset` from
  `immersive-experience-engine/games`) in the same call to switch the
  experience; import that entry in the same dynamic import.
- Reduced motion, missing WebGL and slow devices get the built-in static
  fallback; use `onTierChange` to adapt the page (for example collapse the tall
  scroll wrapper when the tier is `fallback`).

## Timeline

Two timeline modes, chosen by the preset:

- **formation** (`mindFormationPreset`): the intro assembles the final form;
  scrolling runs the chain backwards and dissolves it.
- **sequence** (`gamesPreset`, `blogPreset`): the intro assembles the first
  form; scrolling morphs forward through every following stage and back.

Mind formation:

```text
morph 0 exit ── 1 field ── 2 neural network ── 3 brain ── 4 humanoid

intro   0.4 → 4 over `introDuration` (default 5.4 s)
scroll  4 → 0 across the scroll range of `scrollTarget`
render  hold(min(intro, scroll))   (reversible: scrolling up reassembles)
```

- `hold` eases every stage-to-stage step, so each shape (network, brain,
  humanoid) holds briefly on the intro and while scrolling in either direction.
  The intro adds short pauses: a beat of loose field, then network, then a
  slightly longer brain moment; the humanoid completes at about 5.2 s.
- Structured stages are matched to the next stage's particle order
  (`morph/correspondence.ts`), so network → brain → humanoid moves particles to
  nearby targets. Forms can label groups (`PointCloud.groups`): the brain's
  tissue is matched to the humanoid's inner brain, so the brain condenses into
  the head instead of scattering.
- Every step has its own per-particle delays. Structured steps sweep as a thin
  front: upward into the brain (it rises from the stem while the network still
  stands above), downward into the humanoid (crown to shoulders, face last).
  In-flight particles follow a slight arc with a cool glow.
- The brain stage shows sulcus contour lines, fissure rims and travelling
  waves of neural activity.

Games:

```text
morph 0 exit ── 1 field ── 2 arcade ── 3 controller ── 4 handheld ── 5 pixel world ── 6 arcade

intro   0.4 → 2 over `introDuration` (default 3.6 s)
scroll  2 → 6 across the scroll range of `scrollTarget`
render  hold(intro + scroll)   (reversible, no dissolve)
```

Blog:

```text
morph 0 exit ── 1 field ── 2 page ── 3 discovery lens ── 4 media orbit ── 5 idea globe ── 6 page

intro   0.4 → 2 over `introDuration` (default 3.8 s)
scroll  2 → 6 across the scroll range of `scrollTarget`
render  hold(intro + scroll)   (reversible, no dissolve)
```

## Architecture

```text
src/
├── core/          ImmersiveEngine (orchestration, loop, lifecycle), types, random
├── index.ts       Core entry
├── games.ts       Games entry
├── blog.ts        Blog entry
├── presets/       ExperiencePreset types, mindFormationPreset, gamesPreset, blogPreset
├── timeline/      Timeline (formation and sequence modes, stage holds)
├── particles/     ParticleSystem (one Points draw call) + GLSL shaders
├── morph/         MorphSystem (stage targets as attributes, delays), correspondence
├── forms/         HumanoidForm, BrainForm, NeuralNetworkForm, Field/Exit/Sphere/CustomPointCloud, shapes
│   ├── games/     ArcadeMachineForm, ControllerForm, HandheldForm, PixelWorldForm
│   └── blog/      PageForm, DiscoveryLensForm, MediaOrbitForm, IdeaGlobeForm, editorial shapes
├── interaction/   MouseInteraction (pointer → parallax + shader displacement)
├── scroll/        ScrollController (smoothed scroll progress)
├── camera/        CameraController (parallax, dolly, framing)
├── lights/        LightSystem (mind-core glow and light streak)
├── performance/   PerformanceManager (tier detection, runtime downgrade)
└── fallback/      FallbackRenderer (static, WebGL-free background), neon games and editorial illustrations
demo/              Demo scripts and styles (index.html, games.html and blog.html at the root)
```

- All morph interpolation, turbulence, pointer displacement and fading run in the
  vertex shader. No per-particle work on the CPU after initialization.
- Responsive framing (`avoid` option): the subject goes into the largest free
  area beside the page copy. The camera rig measures the real silhouette of
  every structured stage (network, brain, humanoid with shoulders) in
  perspective at every pointer-parallax and sway pose, and fits it into that
  area: as large as possible up to the desktop scale, shifted only as needed,
  smaller only when the copy leaves too little room.
- Custom forms implement `PointCloudForm` and can replace the stage chain via
  `forms: [exit, field, ...structured, final]` (3–8 stages; each stage is one
  `vec4` attribute: xyz + color tint and size class).
- Shader effects are generated per preset: effects a preset does not enable
  produce no shader code. Optional effects: `colorClasses` and
  `highlightClasses` (size classes drawn in the spark or glow color),
  `depthColor`, `morphWindow`, `transitFade`, `pointerPush`, `pointerGlow`,
  `pointerMagnify`, `neonPulse`, `readingSweep`, `bulge` and `wingFlap`.
- `wingFlap` uses the optional per-particle motion channel: a form may give a
  particle a `motion: [phase, lever]` pair, which correspondence carries along
  the chain and the engine uploads as the `aMotion` attribute. The effect moves
  those particles on the GPU (amplitude, rate and the stage the flap belongs
  to), gated so it stops during the morphs on either side. Presets that do not
  set `wingFlap` get neither the attribute nor any shader code.

## Quality Tiers

| Tier | Particles | Max pixel ratio | Extras |
| ---- | --------- | --------------- | ------ |
| high | 60,000 | 2 | light streak |
| medium | 24,000 | 1.5 | — |
| low | 8,000 | 1 | — |
| fallback | 0 (no WebGL) | — | static gradient + preset illustration (constellation, neon controller, editorial page or app nexus) |

Detection: `prefers-reduced-motion` or no WebGL → fallback; software renderer or
low-power touch devices → low; touch, small screens or ≤ 4 cores → medium;
otherwise high. At runtime, sustained FPS below 40 lowers the tier; sustained
FPS below 20 on low switches to the fallback. Rendering pauses while the hero is
off-screen or the tab is hidden.

## Scripts

| Command | Purpose |
| ------- | ------- |
| `npm run dev` | Demo dev server |
| `npm run typecheck` | TypeScript |
| `npm run lint` | ESLint |
| `npm run build` | Library build (`dist/`, three external, type declarations) |
| `npm run build:demo` | Static demo build (`dist-demo/`) |

## Not Yet Implemented

- Dynamic line-based neural connections
- Post-processing (bloom), advanced lighting
- Automated tests
- Moving form generation off the main thread (at 60,000 particles about 0.3 s
  for the mind formation, 0.5 s for the seven games or blog stages)

# Immersive Experience Engine

Standalone, framework-free hero engine built on Three.js/WebGL. Thousands of GPU
particles assemble from a loose field into a neural network, a digital brain and
a humanoid head, react to the pointer, and dissolve back into particles as the
user scrolls.

Status: **cinematic mind formation** (v0.2.1).

## Quick Start

```bash
npm install
npm run dev
```

Open http://localhost:5199. Query parameters for the demo:

- `?debug` — tier, particle count, FPS and timeline state
- `?tier=high|medium|low|fallback` — force a quality tier

## Usage

```ts
import { createImmersiveEngine } from "immersive-experience-engine";

const engine = createImmersiveEngine({
  container: document.querySelector("#hero-stage")!, // positioned element
  scrollTarget: document.querySelector("#hero")!, // tall wrapper with a sticky viewport
});

// later
engine.dispose();
```

`three` is a peer dependency. The engine returns immediately and builds the
scene when the browser is idle, so it never blocks page content.

## Packaging

The package ships the ES module build and type declarations only (source maps
are excluded from the tarball):

```bash
npm run build
npm pack --pack-destination <consumer>/vendor
```

A consumer installs the versioned tarball, which npm copies into
`node_modules` (no symlink, so bundlers with a project-root boundary such as
Turbopack and hosted builds resolve it like any other dependency):

```json
"dependencies": {
  "immersive-experience-engine": "file:vendor/immersive-experience-engine-0.2.1.tgz",
  "three": "^0.186.0"
}
```

## React / Next.js Integration

The engine is framework-free and touches `window`, so load it on the client
only, after mount, and dispose it on unmount:

```tsx
"use client";

import { useEffect, useRef } from "react";

export function ImmersiveStage() {
  const stage = useRef<HTMLDivElement>(null);

  useEffect(() => {
    let cancelled = false;
    let engine: { dispose(): void } | null = null;

    import("immersive-experience-engine").then(({ createImmersiveEngine }) => {
      const container = stage.current;
      if (cancelled || !container) return;
      const hero = container.closest<HTMLElement>("[data-immersive-hero]") ?? container;
      engine = createImmersiveEngine({
        container,
        scrollTarget: hero, // tall wrapper with a sticky viewport inside
        avoid: [...hero.querySelectorAll("[data-immersive-avoid]")], // headline, copy, CTAs
      });
    });

    return () => {
      cancelled = true; // also safe under React Strict Mode double mounting
      engine?.dispose();
    };
  }, []);

  return <div ref={stage} aria-hidden="true" style={{ position: "absolute", inset: 0 }} />;
}
```

- Keep the headline and CTA in server-rendered HTML; the canvas is decorative
  (`aria-hidden`) and the engine never blocks first paint.
- The dynamic `import()` keeps the engine and three.js in a separate client
  chunk, downloaded only when the component actually mounts (e.g. behind a
  feature flag).
- Reduced motion, missing WebGL and slow devices get the built-in static
  fallback; use `onTierChange` to adapt the page (for example collapse the tall
  scroll wrapper when the tier is `fallback`).

## Timeline

```text
morph 0 exit ── 1 field ── 2 neural network ── 3 brain ── 4 humanoid

intro   0.4 → 4 over `introDuration` (default 5.4 s)
scroll  4 → 0 across the scroll range of `scrollTarget`
render  hold(min(intro, scroll))   (reversible: scrolling up reassembles)
```

- `hold` eases every stage-to-stage step, so each shape (network, brain,
  humanoid) holds briefly on the intro and while scrolling in either direction.
  The intro adds short pauses: a beat of loose field, then network, then a
  slightly longer brain moment; the humanoid completes at about 5.2 s.
- Structured stages are matched to the next stage's particle order
  (`morph/correspondence.ts`), so network → brain → humanoid moves particles to
  nearby targets. Forms can label groups (`PointCloud.groups`): the brain's
  tissue is matched to the humanoid's inner brain, so the brain condenses into
  the head instead of scattering.
- Every step has its own per-particle delays. Structured steps sweep as a thin
  front: upward into the brain (it rises from the stem while the network still
  stands above), downward into the humanoid (crown to shoulders, face last).
  In-flight particles follow a slight arc with a cool glow.
- The brain stage shows sulcus contour lines, fissure rims and travelling
  waves of neural activity.

## Architecture

```text
src/
├── core/          ImmersiveEngine (orchestration, loop, lifecycle), types, random
├── particles/     ParticleSystem (one Points draw call) + GLSL shaders
├── morph/         MorphSystem (stage targets as attributes, timeline), correspondence
├── forms/         HumanoidForm, BrainForm, NeuralNetworkForm, Field/Exit/Sphere/CustomPointCloud
├── interaction/   MouseInteraction (pointer → parallax + shader displacement)
├── scroll/        ScrollController (smoothed scroll progress)
├── camera/        CameraController (parallax, dolly, framing)
├── lights/        LightSystem (mind-core glow and light streak)
├── performance/   PerformanceManager (tier detection, runtime downgrade)
└── fallback/      FallbackRenderer (static, WebGL-free background)
demo/              Demo page script and styles (index.html at the root)
```

- All morph interpolation, turbulence, pointer displacement and fading run in the
  vertex shader. No per-particle work on the CPU after initialization.
- Responsive framing (`avoid` option): the subject goes into the largest free
  area beside the page copy. The camera rig measures the real silhouette of
  every structured stage (network, brain, humanoid with shoulders) in
  perspective at every pointer-parallax and sway pose, and fits it into that
  area: as large as possible up to the desktop scale, shifted only as needed,
  smaller only when the copy leaves too little room.
- Custom forms implement `PointCloudForm` and can replace the stage chain via
  `forms: [exit, field, ...structured, final]` (3–8 stages; each stage is one
  `vec4` attribute: xyz + color tint).

## Quality Tiers

| Tier | Particles | Max pixel ratio | Extras |
| ---- | --------- | --------------- | ------ |
| high | 60,000 | 2 | light streak |
| medium | 24,000 | 1.5 | — |
| low | 8,000 | 1 | — |
| fallback | 0 (no WebGL) | — | static gradient + constellation |

Detection: `prefers-reduced-motion` or no WebGL → fallback; software renderer or
low-power touch devices → low; touch, small screens or ≤ 4 cores → medium;
otherwise high. At runtime, sustained FPS below 40 lowers the tier; sustained
FPS below 20 on low switches to the fallback. Rendering pauses while the hero is
off-screen or the tab is hidden.

## Scripts

| Command | Purpose |
| ------- | ------- |
| `npm run dev` | Demo dev server |
| `npm run typecheck` | TypeScript |
| `npm run lint` | ESLint |
| `npm run build` | Library build (`dist/`, three external, type declarations) |
| `npm run build:demo` | Static demo build (`dist-demo/`) |

## Not Yet Implemented

- Dynamic line-based neural connections
- Post-processing (bloom), advanced lighting
- Automated tests
- Moving form generation off the main thread (about 0.3 s at 60,000 particles)
